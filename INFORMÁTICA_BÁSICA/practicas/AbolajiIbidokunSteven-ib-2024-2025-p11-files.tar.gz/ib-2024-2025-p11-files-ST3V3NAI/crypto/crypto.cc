/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica 2023-2024
 *
 * @author Steven Abolaji Ibidokun alu0101619613@ull.edu.es
 * @date Nov 26 2024
 * @brief  este programa crypto.cc tiene la finalidad de encriptar y/o desencriptar ficheros de texto. 
 * @bug There are no known bugs
 * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
 */

#include "crypto.h"
#include <iostream>
#include <fstream>

Crypto::Crypto(const std::string &inputFile, const std::string &outputFile, int method, const std::string &key, char operation)
    : inputFile(inputFile), outputFile(outputFile), method(method), key(key), operation(operation) {}

/// @brief Abre y desencripta el crypto
void Crypto::xorEncryptDecrypt() {
    std::ifstream inFile(inputFile, std::ios::binary);
    std::ofstream outFile(outputFile, std::ios::binary);

    if (!inFile) {
        std::cerr << "Error: No se pudo abrir el fichero de entrada." << std::endl;
        return;
    }

    char byte;
    std::size_t keyIndex = 0;

    while (inFile.get(byte)) {
        byte ^= key[keyIndex];
        keyIndex = (keyIndex + 1) % key.size();

        outFile.put(byte);
    }

    inFile.close();
    outFile.close();
}


/// @brief Función que desencrypta el encriptado
void Crypto::caesarEncryptDecrypt() {
    std::ifstream inFile(inputFile);
    std::ofstream outFile(outputFile);

    if (!inFile) {
        std::cerr << "Error: No se pudo abrir el fichero de entrada." << std::endl;
        return;
    }

    int shift = std::stoi(key);
    if (operation == '-') {
        shift = -shift; // Invertir el desplazamiento para desencriptar
    }

    char ch;
    while (inFile.get(ch)) {
        if (std::isalpha(ch)) {
            char base = (std::isupper(ch)) ? 'A' : 'a';
            ch = static_cast<char>((ch - base + shift + 26) % 26 + base);
        }
        outFile.put(ch);
    }

    inFile.close();
    outFile.close();
}

/// @brief Función que dependiendo de que opción escojas del menú, te facilita una u otra
void Crypto::processFile() {
    switch (method) {
        case 1:
            xorEncryptDecrypt();
            break;
        case 2:
            caesarEncryptDecrypt();
            break;
        default:
            std::cerr << "Error: Método no válido." << std::endl;
            break;
    }
}

/// @brief Función que te imprime el menu del encriptado
void Crypto::printHelp() {
    std::cout << "./cripto -- Cifrado de ficheros" << std::endl;
    std::cout << "Modo de uso: ./cripto fichero_entrada fichero_salida método password operación" << std::endl;
    std::cout << std::endl;
    std::cout << "fichero_entrada: Fichero a codificar" << std::endl;
    std::cout << "fichero_salida:  Fichero codificado" << std::endl;
    std::cout << "método:          Indica el método de encriptado" << std::endl;
    std::cout << "                   1: Cifrado xor" << std::endl;
    std::cout << "                   2: Cifrado de César" << std::endl;
    std::cout << "password:        Palabra secreta en el caso de método 1, Valor de K en el método 2" << std::endl;
    std::cout << "operación:       Operación a realizar en el fichero" << std::endl;
    std::cout << "                   +: encriptar el fichero" << std::endl;
    std::cout << "                   -: desencriptar el fichero" << std::endl;
}

