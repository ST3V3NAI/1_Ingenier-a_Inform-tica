/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica 2023-2024
 *
 * @author Steven Abolaji Ibidokun alu0101619613@ull.edu.es
 * @date Nov 26 2023
 * @brief Declaracion de la Clase 
 * @bug There are no known bugs
 * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
 */

#include <string>

#ifndef CRYPTO_H
#define CRYPTO_H

class Crypto {
public:
    Crypto(const std::string &inputFile, const std::string &outputFile, int method, const std::string &key, char operation);

    void processFile();

private:
    std::string inputFile;
    std::string outputFile;
    int method;
    std::string key;
    char operation;

    void xorEncryptDecrypt();
    void caesarEncryptDecrypt();
    void printHelp();
};

#endif