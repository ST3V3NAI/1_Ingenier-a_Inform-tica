/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica 2023-2024
 *
 * @author Steven Abolaji Ibidokun alu0101619613@ull.edu.es
 * @date Nov 26 2023
 * @brief  este programa cripto.cc tiene la finalidad de encriptar y/o desencriptar ficheros de texto. 
 * @bug There are no known bugs
 * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
 */

#include <iostream>
#include "crypto.h"

int main(int argc, char *argv[]) {
    if (argc == 2 && std::string(argv[1]) == "--help") {
        Crypto::printHelp();
        return 0;
    }

    if (argc != 6) {
        std::cerr << "Error: Cantidad incorrecta de argumentos." << std::endl;
        std::cerr << "Pruebe ./cripto --help para más información." << std::endl;
        return 1;
    }

    std::string inputFile = argv[1];
    std::string outputFile = argv[2];
    int method = std::stoi(argv[3]);
    std::string key = argv[4];
    char operation = argv[5][0];

    Crypto crypto(inputFile, outputFile, method, key, operation);
    crypto.processFile();

    return 0;
}