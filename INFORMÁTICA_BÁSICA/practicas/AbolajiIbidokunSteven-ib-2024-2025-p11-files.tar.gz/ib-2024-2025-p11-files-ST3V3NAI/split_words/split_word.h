/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file vowels_and_consonants.h
  * @author Steven
  * @date Nov 25 2024
  * @brief Definicion Funciones del programa
  * @bug There are no known bugs
  */


#ifndef SPLIT_WORD_H
#define SPLIT_WORD_H

#include <fstream>
#include <sstream>
#include <cctype>
#include <map>
#include <vector>

void PrintProgramPurpose();
bool CheckCorrectParameters(int argc, char *argv[], const int kCorrectNumber);
std::map<char, std::vector<std::string>> splitWordsByInitial(const std::string &filename);

#endif