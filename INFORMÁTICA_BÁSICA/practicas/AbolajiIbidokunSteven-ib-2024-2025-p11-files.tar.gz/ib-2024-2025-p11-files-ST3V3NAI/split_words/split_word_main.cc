/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file split_word_main.cc
  * @author Steven
  * @date Nov 25 2024
  * @brief Implementación de funciones
  * @bug There are no known bugs
  */

#include "split_word.h"
#include <string>
#include <iostream>


/// @brief Function that the main purpose is to write the letters splitted 
/// @param[in] filename 
/// @param[in] words 
void writeToFile(const std::string &filename, const std::vector<std::string> &words) {
    std::ofstream outputFile(filename);

    if (!outputFile) {
        std::cerr << "No se pudo crear el archivo: " << filename << std::endl;
        return;
    }

    for (const auto &word : words) {
        outputFile << word << std::endl;
    }
}

int main (int argc, char *argv[]) {
  PrintProgramPurpose();

  if(!CheckCorrectParameters(argc, argv, 2)){
    return 1;
  }

  std::map<char, std::vector<std::string>> wordMap = splitWordsByInitial(argv[1]);

    for (char initial = 'A'; initial <= 'Z'; ++initial) {
        std::string outputFileName = std::string(1, initial) + ".txt";
        auto it = wordMap.find(initial);

        if (it != wordMap.end()) {
            writeToFile(outputFileName, it->second);
        }
    }
    
  return 0;
}