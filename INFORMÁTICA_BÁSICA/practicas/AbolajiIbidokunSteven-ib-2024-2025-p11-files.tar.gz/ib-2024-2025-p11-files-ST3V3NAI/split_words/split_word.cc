/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file split_word.cc
  * @author Steven
  * @date Nov 25 2024
  * @brief Programa que separa las letras de un archivo de texto y te lo manda a diferentes archivos de texto
  * @bug There are no known bugs
  */

#include "split_word.h"
#include <string>
#include <iostream>

/// @brief Function that prints the purpose of the program
void PrintProgramPurpose() {
   std::cout << "Given a file, this program separates the initial letters and send them to another file" << std::endl << std::endl;
}

/// @brief Function that check the correct amount of parameters given
/// @param[in] argc 
/// @param[in] argv 
/// @param[in] kCorrectNumber A constant number of parameters
/// @return true or false 
bool CheckCorrectParameters(const int argc, char *argv[], const int kCorrectNumber = 2) {
  if (argc != kCorrectNumber) {
    std::cout << "This program has been executed with a wrong number of parameters." << std::endl;
    std::cout << "This program should be called as: " << argv[0] << "<nombre_del_archivo> " << std::endl;
    return false;
  }
  return true;
}

/// @brief Function that split the words of a file given
/// @param filename 
/// @return result 
std::map<char, std::vector<std::string>> splitWordsByInitial(const std::string &filename) {
    std::map<char, std::vector<std::string>> result;

    std::ifstream inputFile(filename);

    if (!inputFile) {
        std::cerr << "No se pudo abrir el archivo: " << filename << std::endl;
        return result;
    }

    std::string line;
    while (std::getline(inputFile, line)) {
        std::istringstream iss(line);
        std::string word;
        while (iss >> word) {
            if (!word.empty() && std::isalpha(word[0])) {
                char initial = std::toupper(word[0]);
                result[initial].push_back(word);
            }
        }
    }

    return result;
}
