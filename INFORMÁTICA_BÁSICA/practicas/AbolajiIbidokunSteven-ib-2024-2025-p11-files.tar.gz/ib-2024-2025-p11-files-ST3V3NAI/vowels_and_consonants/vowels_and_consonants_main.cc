/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file vowels_and_consonants_main.cc
  * @author Steven
  * @date Nov 25 2024
  * @brief Implementación de funciones pa transformar los grados
  * @bug There are no known bugs
  */

#include "vowels_and_consonants.h"
#include <string>
#include <iostream>

int main (int argc, char *argv[]) {
  PrintProgramPurpose();

  if(!CheckCorrectParameters(argc, argv, 2)){
    return 1;
  }

  std::ifstream inputFile(argv[1]);
  
  if(!inputFile) {
    std::cerr << "No se pudo abrir el archivo: " << argv[1] << std::endl;
    return 1;
  }

  std::string line;
  std::string maxVowelWord, maxConsonantWord;
  int maxVowels = 0, maxConsonants = 0;

  while (std::getline(inputFile, line)){
    std::istringstream iss(line);
    std::string word;

    while (iss >> word) {
        std::string lowerCaseWord = toLowerCase(word);

        int vowelsCount = countVowels(lowerCaseWord);
        int consonantsCount = countConsonants(lowerCaseWord);

        if (vowelsCount > maxVowels) {
            maxVowels = vowelsCount;
            maxVowelWord = word;
        }

        if (consonantsCount > maxConsonants) {
            maxConsonants = consonantsCount;
            maxConsonantWord = word;
        }
    }
  }

  std::cout << "Palabra con más vocales: " << maxVowelWord << " (Numero de vocales: " << maxVowels << ")" << std::endl;
  std::cout << "Palabra con más consonantes: " << maxConsonantWord << " (Número de consonantes: " << maxConsonants << ")" << std::endl;

  return 0;
}