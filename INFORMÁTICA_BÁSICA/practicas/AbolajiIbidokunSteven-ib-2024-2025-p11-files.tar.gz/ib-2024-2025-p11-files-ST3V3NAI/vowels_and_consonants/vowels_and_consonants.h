/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file vowels_and_consonants.h
  * @author Steven
  * @date Nov 25 2024
  * @brief Definicion Funciones del programa
  * @bug There are no known bugs
  */


#ifndef VOWELS_AND_CONSONANTS_H
#define VOWELS_AND_CONSONANTS_H

#include <fstream>
#include <sstream>

void PrintProgramPurpose();
bool CheckCorrectParameters(int argc, char *argv[], const int kCorrectNumber);
int countConsonants(const std::string &str);
int countVowels(const std::string &str);
std::string toLowerCase(const std::string &str);

#endif