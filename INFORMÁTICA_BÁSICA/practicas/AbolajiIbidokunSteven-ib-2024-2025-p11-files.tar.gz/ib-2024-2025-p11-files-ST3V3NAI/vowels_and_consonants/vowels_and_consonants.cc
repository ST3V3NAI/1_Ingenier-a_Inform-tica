/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file vowels_and_cons.cc
  * @author Steven
  * @date Nov 25 2024
  * @brief This program prints the word with most vocals and consonants
  * @bug There are no known bugs
  */

#include "vowels_and_consonants.h"
#include <string>
#include <iostream>
#include <cmath>

/// @brief Function that prints the purpose of the program
void PrintProgramPurpose() {
   std::cout << " This program prints the word with most vocals and consonants, if there is a tie, then he will takes the word that appeared before in the texts" << std::endl << std::endl;
}

/// @brief Function that check the correct amount of parameters given
/// @param[in] argc 
/// @param[in] argv 
/// @param[in] kCorrectNumber A constant number of parameters
/// @return true or false 
bool CheckCorrectParameters(const int argc, char *argv[], const int kCorrectNumber = 2) {
  if (argc != kCorrectNumber) {
    std::cout << "This program has been executed with a wrong number of parameters." << std::endl;
    std::cout << "This program should be called as: " << argv[0] << "<nombre_del_archivo> " << std::endl;
    return false;
  }
  return true;
}


/// @brief Function that turns any phrase to lowercase
/// @param[in] str 
/// @return result
std::string toLowerCase(const std::string &str) {
    std::string result;
    for (char c : str) {
        result += std::tolower(c);
    }
    return result;
}

/// @brief Function that counts the vowels of the string given
/// @param[in] str 
/// @return count
int countVowels(const std::string &str) {
    const std::string vowels = "aeiouAEIOU";
    int count = 0;
    for (char c : str) {
        if (vowels.find(c) != std::string::npos) {
            count++;
        }
    }
    return count;
}

/// @brief Function that counts the consonants of a string
/// @param[in] str 
/// @return count
int countConsonants(const std::string &str) {
    const std::string consonants = "bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ";
    int count = 0;
    for (char c : str) {
        if (consonants.find(c) != std::string::npos) {
            count++;
        }
    }
    return count;
}

