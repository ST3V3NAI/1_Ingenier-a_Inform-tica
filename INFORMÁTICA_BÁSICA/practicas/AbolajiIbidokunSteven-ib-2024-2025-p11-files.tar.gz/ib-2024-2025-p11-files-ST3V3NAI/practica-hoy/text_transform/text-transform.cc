/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica 2023-2024
 *
 * @author Steven Abolaji Ibidokun alu0101619613@ull.edu.es
 * @date Dec 2 2023
 * @brief  Este programa toma como parámetros por línea de comandos los nomnres de dos ficheros 
 * procesa el primero de ellos escirbiendo la salida en el segundo. El programa ha de cambiar en 
 * el primer fichero todas las letras por "la siguiente letra"
 * @bug There are no known bugs
 * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
 */

#include <iostream>
#include <cctype>
#include <fstream>
#include <string>

void PrintProgramPurpose() {
  std::cout << "Este programa toma un archivo de entrada y escribe en un archivo de salida con cada letra cambiada por su siguiente letra en el alfabeto." << std::endl << std::endl;
}

bool CheckCorrectParameters(const int argc, char *argv[], const int kCorrectNumber = 3) {
  if (argc != kCorrectNumber) {
    std::cout << "This program has been executed with a wrong number of parameters." << std::endl;
    std::cout << "This program should be called as: " << argv[0] << " <ficheroEntrada.txt> <ficheroSalida.txt>" << std::endl;
    return false;
  }
  return true;
}

std::string SiguienteLetraAlfabeto(std::string phrase) {
    std::string resultado;
    for(char character : phrase) {
        if(character >= 'a' && character <= 'y') {
            resultado += character + 1;
        } else if (character == 'z') {
            resultado += 'a'; 
        } else if (character >= 'A' && character <= 'Y') {
            resultado += character + 1;
        } else if (character == 'Z') {
            resultado += 'A';
        } else {
            resultado += character;
        }
    }

    return resultado; 
}

void EnviarTextoDeUnArchivoAOtro(const std::string& ficheroEntrada, const std::string& ficheroSalida) {
    std::ifstream archivoEntrada(ficheroEntrada);
    std::ofstream archivoSalida(ficheroSalida);

    std::string linea; 

    if(!archivoEntrada) {
        std::cerr << "Error: No se pudo abrir el archivo de entrada." << std::endl;
        return;
    }

    if (!archivoSalida) {
        std::cerr << "Error: No se pudo abrir el archivo de salida" << std::endl;
        return;
    }

    while (getline(archivoEntrada, linea)) {
            archivoSalida << SiguienteLetraAlfabeto(linea) << std::endl;
    }

    archivoEntrada.close();
    archivoSalida.close();
} 


int main(int argc, char *argv[]) {
  PrintProgramPurpose();

  if (!CheckCorrectParameters(argc, argv, 3)) {
    return 1;
  }

  std::string archivoEntrada = argv[1];
  std::string archivoSalida = argv[2];

  EnviarTextoDeUnArchivoAOtro(archivoEntrada, archivoSalida);

  return 0;
}

