/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica 2023-2024
 *
 * @author Steven Abolaji Ibidokun alu0101619613@ull.edu.es
 * @date Dec 2 2023
 * @brief  Este programa coge la palabra más pequeña y la más grande y las manda al otro fichero con una linea separada
 * @bug There are no known bugs
 * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
 */

#include <iostream>
#include <cctype>
#include <fstream>
#include <string>
#include <algorithm>

void PrintProgramPurpose() {
  std::cout << "Este programa toma un archivo de entrada y escribe en un archivo de salida dos letras: la más grande y la más pequeña" << std::endl << std::endl;
}

bool CheckCorrectParameters(const int argc, char *argv[], const int kCorrectNumber = 3) {
  if (argc != kCorrectNumber) {
    std::cout << "This program has been executed with a wrong number of parameters." << std::endl;
    std::cout << "This program should be called as: " << argv[0] << " <ficheroEntrada.txt> <ficheroSalida.txt>" << std::endl;
    return false;
  }
  return true;
}

std::string InversoDeUnaFrase(std::string &phrase) {
    std::string inversa = phrase;
    std::reverse(inversa.begin(), inversa.end());
    return inversa;
}



void EnviarTextoDeUnArchivoAOtro(const std::string& ficheroEntrada, const std::string& ficheroSalida) {
    std::ifstream archivoEntrada(ficheroEntrada);
    std::ofstream archivoSalida(ficheroSalida);

    if(!archivoEntrada) {
        std::cerr << "Error: No se pudo abrir el archivo de entrada." << std::endl;
        return;
    }

    if (!archivoSalida) {
        std::cerr << "Error: No se pudo abrir el archivo de salida" << std::endl;
        return;
    }

    std::string linea; 
    while (getline(archivoEntrada, linea)) {
            archivoSalida << InversoDeUnaFrase(linea) << std::endl;
    }

    archivoEntrada.close();
    archivoSalida.close();
} 


int main(int argc, char *argv[]) {
  PrintProgramPurpose();

  if (!CheckCorrectParameters(argc, argv, 3)) {
    return 1;
  }

  std::string archivoEntrada = argv[1];
  std::string archivoSalida = argv[2];

  EnviarTextoDeUnArchivoAOtro(archivoEntrada, archivoSalida);

  return 0;
}