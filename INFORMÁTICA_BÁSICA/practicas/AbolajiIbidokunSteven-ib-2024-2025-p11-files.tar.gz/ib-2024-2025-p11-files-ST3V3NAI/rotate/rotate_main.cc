/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file vowels_and_consonants_main.cc
  * @author Steven
  * @date Nov 25 2024
  * @brief Implementación de funciones pa transformar los grados
  * @bug There are no known bugs
  */

#include "rotate.h"
#include <string>
#include <iostream>

int main (int argc, char *argv[]) {
  PrintProgramPurpose();

  if(!CheckCorrectParameters(argc, argv, 2)){
    return 1;
  }

  std::ifstream inputFile(argv[1]);
  
  if(!inputFile) {
    std::cerr << "No se pudo abrir el archivo: " << argv[1] << std::endl;
    return 1;
  }


  std::string line;

  while (std::getline(inputFile, line)) {
    std::cout << rotateVowels(line) << std::endl;
  }

  return 0;
}