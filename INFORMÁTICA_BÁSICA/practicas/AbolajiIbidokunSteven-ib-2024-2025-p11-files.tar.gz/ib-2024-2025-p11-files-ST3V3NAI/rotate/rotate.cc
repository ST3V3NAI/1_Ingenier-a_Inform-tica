/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file rotate.cc
  * @author Steven
  * @date Nov 25 2024
  * @brief Programa que al el valor minimo, maximo y su diferencia te va transformando los grados
  * @bug There are no known bugs
  */

#include "rotate.h"
#include <string>
#include <iostream>

/// @brief Function that prints the purpose of the program
void PrintProgramPurpose() {
   std::cout << "This program rotates the vowels wrote in uppercase" << std::endl << std::endl;
}

/// @brief Function that check the correct amount of parameters given
/// @param[in] argc 
/// @param[in] argv 
/// @param[in] kCorrectNumber 
/// @return true or false
bool CheckCorrectParameters(const int argc, char *argv[], const int kCorrectNumber = 2) {
  if (argc != kCorrectNumber) {
    std::cout << "This program has been executed with a wrong number of parameters." << std::endl;
    std::cout << "This program should be called as: " << argv[0] << "<nombre_del_archivo> " << std::endl;
    return false;
  }
  return true;
}

/// @brief Function that identifies some vocals and rotates them
/// @param[in] str 
/// @return result
std::string rotateVowels(const std::string &str) {
    std::string result = str;
    for (char &c : result) {
        switch (c) {
            case 'a':
                c = 'e';
                break;
            case 'e':
                c = 'i';
                break;
            case 'i':
                c = 'o';
                break;
            case 'o':
                c = 'u';
                break;
            case 'u':
                c = 'a';
                break;
        }
    }
    return result;
}

