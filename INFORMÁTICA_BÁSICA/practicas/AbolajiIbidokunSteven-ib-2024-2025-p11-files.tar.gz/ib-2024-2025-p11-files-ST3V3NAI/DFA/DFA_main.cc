/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file DFA_main.cc
  * @author Steven
  * @date Nov 25 2024
  * @brief Implementación de funciones 
  * @bug There are no known bugs
  */

#include "DFA.h"
#include <string>
#include <iostream>

int main (int argc, char *argv[]) {
  PrintProgramPurpose();

  if(!CheckCorrectParameters(argc, argv, 2)){
    return 1;
  }

  std::ifstream inputFile(argv[1]);
  
  if(!inputFile) {
    std::cerr << "No se pudo abrir el archivo: " << argv[1] << std::endl;
    return 1;
  }

    DFA dfa;
    dfa.readFromFile(argv[1]);
    dfa.printInfo();

    return 0;
}