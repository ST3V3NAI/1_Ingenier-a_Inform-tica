/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica 2023-2024
 *
 * @author Steven Abolaji Ibidokun alu0101619613@ull.edu.es
 * @date Nov 26 2024
 * @brief  Este programa, denominado read_DFA.cc, lee un fichero de texto (input.dfa) que especifica un Autómata Finito Determinista (DFA). A través de la lectura del archivo, imprime en pantalla las características del DFA, incluyendo el número total de estados, el estado inicial, el conjunto de estados de aceptación, y la función de transición para cada estado y símbolo de entrada. El formato de salida sigue las convenciones indicadas en el ejemplo proporcionado, mostrando la información esencial del DFA.
 * @bug There are no known bugs
 * @see https://www.cs.cmu.edu/~410/doc/doxygen.html
 */

#include <vector>
#include <iostream>
#include <fstream>

void PrintProgramPurpose();
bool CheckCorrectParameters(int argc, char *argv[], const int kCorrectNumber);

struct Transition {
    char symbol;
    unsigned int destination;
};

class DFA {
public:
    DFA();

    void readFromFile(const std::string &filename);
    void printInfo() const;

private:
    unsigned int numStates;
    unsigned int startState;
    std::vector<bool> acceptingStates;
    std::vector<std::vector<Transition>> transitions;
};
