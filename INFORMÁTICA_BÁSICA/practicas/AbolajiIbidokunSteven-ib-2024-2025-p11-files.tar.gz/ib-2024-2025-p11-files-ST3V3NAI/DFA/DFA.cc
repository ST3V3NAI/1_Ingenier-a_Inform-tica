/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file DFA.cc
  * @author Steven
  * @date Nov 25 2024
  * @brief Programa que acepta o rechaza una determinada secuencia de símbolos
  */

#include "DFA.h"
#include <fstream>
#include <sstream>

void PrintProgramPurpose() {
   std::cout << "This program that accepts or rejets a certain sequence of symbols" << std::endl << std::endl;
}

bool CheckCorrectParameters(const int argc, char *argv[], const int kCorrectNumber = 2) {
  if (argc != kCorrectNumber) {
    std::cout << "This program has been executed with a wrong number of parameters." << std::endl;
    std::cout << "This program should be called as: " << argv[0] << "<nombre_del_archivo> " << std::endl;
    return false;
  }
  return true;
}


DFA::DFA() {}
/// @brief Function that reads the information of the DFA
/// @param[in] filename 
void DFA::readFromFile(const std::string &filename) {
    std::ifstream inputFile(filename);

    if (!inputFile) {
        std::cerr << "No se pudo abrir el archivo: " << filename << std::endl;
        return;
    }

    inputFile >> numStates;
    inputFile >> startState;

    acceptingStates.resize(numStates, false);
    transitions.resize(numStates);

    for (unsigned int i = 0; i < numStates; ++i) {
        unsigned int stateId, isAccepting, numTransitions;
        inputFile >> stateId >> isAccepting >> numTransitions;

        acceptingStates[stateId] = (isAccepting == 1);

        for (unsigned int j = 0; j < numTransitions; ++j) {
            char symbol;
            unsigned int destination;
            inputFile >> symbol >> destination;

            transitions[stateId].push_back({symbol, destination});
        }
    }

    inputFile.close();
}

/// @brief Function that prints the information of the DFA
void DFA::printInfo() const {
    std::cout << "|Q| = " << numStates << std::endl;
    std::cout << "q0 = " << startState << std::endl;

    std::cout << "F = {";
    bool first = true;
    for (unsigned int i = 0; i < numStates; ++i) {
        if (acceptingStates[i]) {
            if (!first) {
                std::cout << ", ";
            }
            std::cout << i;
            first = false;
        }
    }
    std::cout << "}" << std::endl;

    for (unsigned int i = 0; i < numStates; ++i) {
        for (const Transition &transition : transitions[i]) {
            std::cout << "delta(" << i << ", " << transition.symbol << ") = " << transition.destination << std::endl;
        }
    }
}