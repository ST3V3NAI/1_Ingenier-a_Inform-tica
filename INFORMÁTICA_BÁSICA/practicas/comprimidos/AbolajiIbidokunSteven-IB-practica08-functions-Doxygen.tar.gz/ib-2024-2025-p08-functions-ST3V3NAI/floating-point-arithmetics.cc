/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author F. de Sande
 * @date Nov 7, 2022
 * @brief Shows floating point arithmetics
 *
 * https://www.geeksforgeeks.org/problem-in-comparing-floating-point-numbers-and-how-to-compare-them-correctly/
 * @see https://stackoverflow.com/a/17341/12791643
 */

#include <iostream>

bool AreaEqual(const double number1, const double number2, const double epsilon = 1e-7){
  if(number1 == number2) {
    return true;
  } else {
    return false;
  }
}

int main() {
  const double kOneThird{0.3333333333};
  const double epsilon = 1e-7;
  std::cout << kOneThird << std::endl;
  const double result = 1.0 / 3; 
  std::cout << result << std::endl;

  AreaEqual(kOneThird, result, epsilon);

  std::cout << std::endl;

  if (1.0 / 3 == kOneThird) {
    std::cout << "Equals" << std::endl;
  }
  else {
    std::cout << "Different" << std::endl;
  }
  return 0;
}
