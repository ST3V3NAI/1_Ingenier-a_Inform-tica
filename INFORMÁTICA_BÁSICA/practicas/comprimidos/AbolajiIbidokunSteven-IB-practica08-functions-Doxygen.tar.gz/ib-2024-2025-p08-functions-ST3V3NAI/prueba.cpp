#include <iostream>
#include <cstdlib>
#include <ctime>

int main() {
    int number_1{}, number_2{}, random_number{};

    std::cin >> number_1 >> number_2;

    if(number_2 > number_1){
      std::srand(std::time(0));
      random_number = std::rand() % number_2; 
    }

    std::cout << random_number << std::endl;
}