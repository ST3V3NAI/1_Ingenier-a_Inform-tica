/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file 1_P58459_Valid_Dates.cc
  * @author alu0101619613@ull.edu.es
  * @date Nov 4 2024
  * @brief Write a function that tells if the date defined by a day d, month m and year y is valid or not.
  * @bug There are no known bugs
  * @see 
  * 
  */

 #include <iostream>

// Declaración de la función
bool is_valid_date(int d, int m, int y);


int main() {
  int dia, mes, anio, fc;
  while (std::cin >> dia >> mes >> anio) {
    std::cout << "is_valid_date("<< dia <<", "<< mes <<", "<< anio <<") -> ";
     if(is_valid_date(dia, mes, anio)==1){
      std::cout <<"true"<< std::endl;
      } else {
        std::cout<< "false"<<std::endl;
      }
  }
  return 0;
}


/// @brief Esta función te dice si el año es bisiesto o no
/// @param y 
/// @return true or false

bool Bisiesto(int y) { // Mira que el año se bisiesto y te retorna y es verdadero o falso
  if (y % 100 == 0) { // SI el año es divisible entre 100 salta al if
    if ((y / 100) % 4 == 0)
      return true;
    return false;
  } else {
    if (y % 4 == 0)
      return true;
    return false;
  }
}


/// @brief Esta función a partir de la anterior te dice si la fecha es válida dependiendo si es bisiesto o no
/// @param d 
/// @param m 
/// @param y 
/// @return true or false

bool is_valid_date(int d, int m, int y) {
  if (d < 1 || m < 1 || y < 1800 || y > 9999 || m > 12 || d > 31) {
    return false;
  }
  if (!Bisiesto(y) && m == 2 && d > 28) { // Comprueba si el año tiene días que sean mayores que 28,  en el caso del mes de febrero
    return false;
  }
  if (m == 2 && d > 29) { // Comprueba si el año tiene días que sean mayores que 29,  en el caso del mes de febrero
    return false;
  }
  if ((m > 7 && m % 2 != 0 && d > 30) || (m <= 7 && m % 2 == 0 && d > 30)) { // Comprueba si el año tiene días que sean mayores que 30,  en el caso del mes de febrero
    return false;
  }
  return true;
}