/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file 2_P57474_Iterative_factorial.cc
  * @author alu0101619613@ull.edu.es
  * @date Nov 11 2024
  * @brief Write an iterative function that, given a natural n, returns its factorial n!.
  * @bug There are no known bugs
  * @see 
  */

#include <iostream>

/// @brief Esta función comprueba si el numero introdido es 0 o 1,  si lo es retorna 1, si no ejercuta la función
/// @param n 
/// @return Retorna el valor de función declarado como int
int factorial(int n) {
  int value = (n == 1 || n == 0) ? 1 : factorial(n-1) * n;
  return value;
}

int main() {
  int number{}; // Inicializamos el valor de number como 0, para que luego el usuario nos lo de

  std::cin >> number; 
  if (number >= 0 && number <= 12) { // Comrpobamos, por prerequisito, que el numero esté entre 0 y 12
  std::cout << factorial(number) << std::endl; 
  } else { // Si no ocurre eso, produce un salto de línea
    std::cout << std::endl;
  }
  return 0;
}
