/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file 3_P55722_Iterative_number_of_Digits.cc
  * @author alu0101619613@ull.edu.es
  * @date Nov 11 2024
  * @brief Write an iterative function, that given a natural number return is factorial
  * @bug There are no known bugs
  * @see 
  */

#include <iostream>
#include <cmath>


/// @brief Esta te devuelve las veces que tiene que iterar el propgrama para conseguir el user_input
/// @param a 
/// @return Te retorna la variable i, declarada como 1, para que se pueda realizar el logaritmo

int number_of_digits(int a) { // declaramos la variable a, como parámetro de la función 
	int i{1}; // Declaramos a como 1, para que se pueda realizar el logaritmo, puesto que con 0 no funciona

  if (a!=0){ // Si el valor de de a es distinto de 0, ejecuta el logaritmo, si no ocurre eso da error
	i = (log10(a)) + 1; // Ejecutamos 1 como el logaritmo de lo que nos introduzca el usuario, para iterarlo // En caso de que no sea posible esto, retornará el valor que nos haya dado el usuario
    }
    return i;
}

int main() {
	int user_input{}; // Inicializamos el user_input por el valor que nos de el usuario

	while(std::cin >> user_input){ // Mientras que el usuario siga introduciendo valores, serguira ejecutándose el programa
	  std::cout <<"number_of_digits("<< user_input <<") -> "<< number_of_digits(user_input) << std::endl;
    }
}