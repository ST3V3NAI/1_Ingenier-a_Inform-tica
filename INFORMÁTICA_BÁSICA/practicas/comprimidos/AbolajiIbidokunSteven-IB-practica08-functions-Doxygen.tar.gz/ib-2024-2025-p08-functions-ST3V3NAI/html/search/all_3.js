var searchData=
[
  ['básica_20lab_20assignment_0',['Informática Básica Lab assignment',['../md_README.html#autotoc_md7',1,'']]]
];
