var searchData=
[
  ['7_0',['Factor de ponderación: 7',['../md_functions.html#autotoc_md1',1,'']]]
];
