var searchData=
[
  ['ponderación_3a_207_0',['Factor de ponderación: 7',['../md_functions.html#autotoc_md1',1,'']]],
  ['práctica_1',['Rúbrica de evaluacion de esta práctica',['../md_functions.html#autotoc_md3',1,'']]],
  ['práctica_2008_20funciones_20doxygen_2',['Práctica 08. Funciones. Doxygen.',['../md_functions.html',1,'']]]
];
