var searchData=
[
  ['de_20estudio_20complementario_0',['Material de estudio complementario',['../md_functions.html#autotoc_md5',1,'']]],
  ['de_20evaluacion_20de_20esta_20práctica_1',['Rúbrica de evaluacion de esta práctica',['../md_functions.html#autotoc_md3',1,'']]],
  ['de_20ponderación_3a_207_2',['Factor de ponderación: 7',['../md_functions.html#autotoc_md1',1,'']]],
  ['doxygen_3',['doxygen',['../md_functions.html#autotoc_md4',1,'Doxygen'],['../md_functions.html',1,'Práctica 08. Funciones. Doxygen.']]]
];
