var searchData=
[
  ['rúbrica_20de_20evaluacion_20de_20esta_20práctica_0',['Rúbrica de evaluacion de esta práctica',['../md_functions.html#autotoc_md3',1,'']]],
  ['readme_1',['README',['../md_README.html',1,'']]]
];
