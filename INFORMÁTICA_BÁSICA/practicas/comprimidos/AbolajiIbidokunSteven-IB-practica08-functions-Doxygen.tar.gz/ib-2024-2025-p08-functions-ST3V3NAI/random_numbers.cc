/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file change-case.cc
  * @author Steven Abolaji Ibidokun alu0101619613@ull.edu.es
  * @date Nov 4 2024
  * @brief Write a program that generates a random number from  an interval given.
  * @see 
  */

#include <iostream>
#include <ctime>
#include <cstdlib>

int GenerateRandomNumber(int number1, int number2){
  if(number2 > number1){
    return number1 + std::rand() % (number2 - number1 + 1);
  } else {
     return 1;
  }
}

int main(){

  int number_1{}, number_2{};

  std::cin >> number_1 >> number_2;

  std::srand(std::time(0));

  int random_number =  GenerateRandomNumber(number_1, number_2);
  std::cout << random_number << std::endl;
  return 0;
}

