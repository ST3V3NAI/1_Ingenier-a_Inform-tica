/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file change-case.cc
  * @author Steven Abolaji Ibidokun alu0101619613@ull.edu.es
  * @date Nov 4 2024
  * @brief Write a program that calculates the function g(x,y,t) = sqrt(2t-4) / (x^2 - y^2).
  * @bug There are no known bugs
  * @see 
  */


#include <iostream>
#include <cmath>

double Function(double number_t, double number_x, double number_y){
  double denominator =  (pow(number_x,2) - pow(number_y,2));
  
  double result = (sqrt((2 * number_t)-4)) / denominator;
  return result;
  
}

int main(){
  double number_t{}, number_x{}, number_y{};

  std::cin >> number_t >> number_x >> number_y;

  std::cout << Function(number_t, number_x, number_y) << std::endl;
    
  return 0;
}