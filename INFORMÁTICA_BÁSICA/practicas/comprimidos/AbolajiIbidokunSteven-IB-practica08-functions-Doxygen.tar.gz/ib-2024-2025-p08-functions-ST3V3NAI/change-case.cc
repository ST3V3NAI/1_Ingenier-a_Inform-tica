/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file change-case.cc
  * @author Steven Abolaji Ibidokun alu0101619613@ull.edu.es
  * @date Nov 4 2024
  * @brief Write a program that reads a string, and depending if it uppercase or lowercase it will change to each case.
  * @bug There are no known bugs
  * @see 
  */

#include <iostream>
#include <string>
#include <iomanip>

char CharacterChangeCase(char character) {
  if (character >= 'a' && character <= 'z') {
    return character - 'a' + 'A';
  } else if (character >= 'A' && character <= 'Z') {
    return character - 'A' + 'a';
  }
  return character;
}

std::string ChangeCase(const std::string& input) {
  std::string result;
  for (char character : input) {
    result += CharacterChangeCase(character);
  }
  return result;
}

int main(){
    std::string input{};
   
    std::cin >> input;


    std::string result = ChangeCase(input);

    std::cout << result << std::endl;

}