/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file P59875_Top_to_bottom.cc
  * @author Steven Abolaji Ibidokun alu0101619613@ull.edu.es
  * @date Nov 4 2024
  * @brief reads two numbers x and y, and prints all numbers between x and y (or between y and x), in decreasing order.
  * @bug There are no known bugs
  * @see https://jutge.org/problems/P59875_en
  */

#include <iostream>

int main() {
  int numero_inicial{}, numero_final{}; // Inicializamos los valores que nos dara el usuario por pantalla

    std::cout << "";
    std::cin >> numero_inicial;
    std::cout << "";
    std::cin >> numero_final;

    // Imprime los numeros de forma descendente
    if (numero_inicial < numero_final) {
        for (int i = numero_final; i >= numero_inicial; i--) {
            std::cout << i << std::endl;
        }
    // Si falla el bucle, imprime los numero de forma ascendente
    } else {
        for (int i = numero_inicial; i >= numero_final; i--) {
            std::cout << i << std::endl;
        }
    }

    return 0;
}
