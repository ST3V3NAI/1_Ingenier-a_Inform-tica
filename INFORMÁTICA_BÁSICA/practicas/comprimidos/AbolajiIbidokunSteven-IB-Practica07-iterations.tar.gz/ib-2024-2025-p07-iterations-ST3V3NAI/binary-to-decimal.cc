/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file binary-to-decimal.cc
  * @author Steven Abolaji Ibidokun alu0101619613@ull.edu.es
  * @date Oct 28 2024
  * @brief Write a program that reads a binary number and prints its 
  * number
  * @bug There are no known bugs
  * @see 
  */

#include <iostream>
#include <string>
#include <cmath>

int BinaryToDecimal(const std::string& binario){
    int decimal{};

    for(size_t i = 0; i < binario.length(); i++){

        char digito = binario[binario.length() - 1 - i];

        if (digito == '1') {
            decimal += pow(2, i);
        } else if(digito != 0) {
            std::cout << "Wrong Input";
            return 1;
        }
    }

    return decimal; 
}




int main(){
    std::string binario{};

    std::cin >> binario;

    std::cout << BinaryToDecimal(binario) << std::endl;

 


}