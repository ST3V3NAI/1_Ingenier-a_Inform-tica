/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file sum-of-natural-numbers.cc
  * @author Steven Abolaji Ibidokun alu0101619613@ull.edu.es
  * @date Oct 28 2024
  * @brief Write a program that reads a natural number and give the sum
  * @bug There are no known bugs
  * @see 
  */


#include <iostream>

int main() {
  int number{}, original_number{number}, sum{};

  std::cin >> number;

  while(number > 0){
    sum += number % 10;
    number /= 10;
  }
 
  std::cout << "" << sum << std::endl;

    return 0;
}