#include <iostream>
#include <cctype>

int main(){
  char letra{};

  std::cout << "Entrada \n" << std::endl;

  std::cout << "\t";

  std::cin >> letra;

  if (std::isupper(letra)){ 
    letra = std::towlower(letra); 
  } else if (std::islower(letra)){ 
    letra = std::toupper(letra);
  }

  std::cout << "Salida \n" << " " << letra << std::endl;


    return 0;
  }

