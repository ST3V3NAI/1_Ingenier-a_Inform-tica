#include <iostream>

int main(){
  std::cout << " \n p     !p   " << std::endl;
  std::cout << "----- -----" << std::endl;
  std::cout << true  << "     " << !true  << std::endl;
  std::cout << false << "     " << !false << std::endl;
  std::cout << std::endl;

  std::cout << "\n p q   p && q" << std::endl; 
  std::cout << "----- ------" << std::endl;
  std::cout << false << " " << false << "   " << (false && false) << std::endl;
  std::cout << false << " " << true  << "   " << (false && true ) << std::endl;
  std::cout << true  << " " << false << "   " << (true  && false) << std::endl;
  std::cout << true  << " " << true  << "   " << (true  && true ) << std::endl;

  std::cout << "\n p q   p || q" << std::endl;
  std::cout << "----- ------" << std::endl;
  std::cout << false << " " << false << "   " << (false || false) << std::endl;
  std::cout << false << " " << true  << "   " << (false || true ) << std::endl;
  std::cout << true  << " " << false << "   " << (true  || false) << std::endl;
  std::cout << true  << " " << true  << "   " << (true  || true ) << std::endl;

  return 0;
}