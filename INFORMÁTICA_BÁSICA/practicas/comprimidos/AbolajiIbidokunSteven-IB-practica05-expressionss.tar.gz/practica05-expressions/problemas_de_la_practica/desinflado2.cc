#include <iostream>

int main() {

    char letra{};

    std::cout << "Entrada: "; 


    std::cin >> letra; 

    if(letra >= 'a' && letra <= 'z') {
        letra = letra - 32;
    } else {
        letra = letra + 32;
    }

    std::cout << "Salida: " << letra << std::endl;

    return 0; 
}