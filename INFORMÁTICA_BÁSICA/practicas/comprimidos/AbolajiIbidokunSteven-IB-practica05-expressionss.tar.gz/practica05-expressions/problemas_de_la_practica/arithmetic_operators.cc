#include <iostream>

int main() {
    // Declaración e inicialización de variables
    int a = 10, b = 3;
    double x = 5.5, y = 2.2;

    // Operaciones aritméticas con enteros
    std::cout << "Enteros:" << std::endl;
    std::cout << "a + b = " << a + b << std::endl;
    std::cout << "a - b = " << a - b << std::endl;
    std::cout << "a * b = " << a * b << std::endl;
    std::cout << "a / b = " << a / b << std::endl; // División entera
    std::cout << "a % b = " << a % b << std::endl; // Módulo

    // Operaciones aritméticas con números de punto flotante
    std::cout << "\nNúmeros de punto flotante:" << std::endl;
    std::cout << "x + y = " << x + y << std::endl;
    std::cout << "x - y = " << x - y << std::endl;
    std::cout << "x * y = " << x * y << std::endl;
    std::cout << "x / y = " << x / y << std::endl;

    // Operadores de comparación con enteros
    std::cout << "\nComparación de enteros:" << std::endl;
    std::cout << "a == b: " << (a == b) << std::endl;
    std::cout << "a != b: " << (a != b) << std::endl;
    std::cout << "a > b: " << (a > b) << std::endl;
    std::cout << "a < b: " << (a < b) << std::endl;
    std::cout << "a >= b: " << (a >= b) << std::endl;
    std::cout << "a <= b: " << (a <= b) << std::endl;

    // Operadores de comparación con números de punto flotante
    std::cout << "\nComparación de números de punto flotante:" << std::endl;
    std::cout << "x == y: " << (x == y) << std::endl;
    std::cout << "x != y: " << (x != y) << std::endl;
    std::cout << "x > y: " << (x > y) << std::endl;
    std::cout << "x < y: " << (x < y) << std::endl;
    std::cout << "x >= y: " << (x >= y) << std::endl;
    std::cout << "x <= y: " << (x <= y) << std::endl;

    return 0;
}