#include <iostream>
using namespace std;

void mostrarComoHora(int numero) {
  // Extraer horas, minutos y segundos
  int horas = numero / 10000;
  int minutos = (numero / 100) % 100;
  int segundos = numero % 100;
    
  // Mostrar en el formato deseado
  cout << horas << ":" << minutos << ":" << segundos << endl;
}

int main() {
  int numero;
  cout << "Introduce un número entero de 6 dígitos (por ejemplo, 145521): ";
  cin >> numero;
    
  mostrarComoHora(numero);
    
  return 0;
}
