#include <iostream>

int main(){

  int a = 1, b = 3;
  char c = 'a', d = 'd';
  double x = 0.0, y = 1.2;
  std::string s1 = "aab", s2 = "ccd";


  a > 1 && b < 2; 
  c == 'z' && d == 'd';
  c != 'a' && c != 'd';
  a == 1 && b == 3;
  s1 > "aaa" && s1 < "zzz";
  s1 != s2 && s1 + "b" == "aabb";
  a / b == 0 && a % b == 0; 




    return 0; 
}