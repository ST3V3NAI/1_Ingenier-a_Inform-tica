#include <iostream>

int main(){

  int a = 5, b = 2, c = 7, d = 1;
  double x = 1.0, y = 0.5, z = 1.5;

  int op1{0}, op2{0}, op3{0}, op4{0}, op5{0}, op6{0}, op7{0};

  op1 = a - b - c;
  op2 = c / b / b;
  op3 = x * z / y;
  op4 = c / (a / b);
  op5 = a  + b*2 + d*(1 - c);
  op6 = x*y + z*2.0*(x - 1.0);
  op7 = 5*(-a) + c*3 - b;

  std::cout << op1 << op2 << op3 << op4 << op5 << op6 << op7;


  return 0;
}