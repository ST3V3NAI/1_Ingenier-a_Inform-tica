/* Programa llamado tutti frutti   */

#include <iostream>


int main(){
  int n = 1, m = 5;
  double d = 2.5, e = 0.8;
  char c1 = 'a', c2 = 'b';
  std::string s1 = "hi", s2 = "ho";

  n < m;
  d < 2.5;
  "ho" == s2; 
  e > 1.0; 
  d > (e + 1.0);
  double(n) > e;
  m < int(d);
  n == (m - 4);
  int(c1) > 90;
  s1 == "s1";
  c1 >= 'a';
  (s1 + "la") >= "hola";
  m >= 5;
  int(d + e) > 3;
  c2 == 'c';
  s1 >= s2;
  int(c2) != 98;
  s2 >= "hola";
  s1 == "hi there!";
  e != d;
  s1 != s1;
  n + 2 < m - 3;
  3 < int(d + e);
 "c1" == s2;



  return 0;
}
