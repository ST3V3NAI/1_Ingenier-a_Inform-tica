#include <iostream>

int main() {
   double x{0};

   std::cin >> x;
   
   bool menor_que_0 = x < 0.0;
   bool mayor_que_1 = x > 1.0;
   bool fuera = menor_que_0 || mayor_que_1;

   std::cout << fuera << std::endl;
}