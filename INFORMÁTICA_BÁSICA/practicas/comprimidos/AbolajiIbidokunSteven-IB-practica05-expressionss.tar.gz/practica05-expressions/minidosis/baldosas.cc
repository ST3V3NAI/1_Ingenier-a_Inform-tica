#include <iostream>

int main(){
  int largo{0};
  double ancho{0};
  double area{0};
  int baldosas{0};

  std::cin >> largo >> ancho;

  area = largo * ancho;

  baldosas = area / ( 0.6 * 0.6 );

  std::cout << "La habitación tendrá " << baldosas << " baldosas enteras";


}