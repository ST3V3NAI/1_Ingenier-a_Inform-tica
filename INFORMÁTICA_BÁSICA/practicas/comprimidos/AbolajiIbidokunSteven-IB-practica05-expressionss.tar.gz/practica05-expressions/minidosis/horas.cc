#include <iostream>

int main(){
  int total_sec{0}, horas{0};

  std::cin >> total_sec;

  horas = total_sec / 3600;

  std::cout << horas << std::endl;

  return 0;
}