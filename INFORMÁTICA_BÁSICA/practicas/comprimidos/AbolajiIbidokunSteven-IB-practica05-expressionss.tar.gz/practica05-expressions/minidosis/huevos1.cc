#include <iostream>

int main(){
  int cajas_de_huevos{0}, total_eggs{0}, sobran_huevos{0};

    std::cout << "Huevos? ";
    std::cin >> total_eggs;
    
    cajas_de_huevos = total_eggs / 6;
    sobran_huevos = total_eggs % 6;

    std::cout << "Con " << total_eggs << " se pueden llenar " << cajas_de_huevos << " cajas y sobran " << sobran_huevos << " huevos ";
    
}