/*Haz un programa que lea 2 números reales que son las coordenadas x e y de un punto del plano 2D.*/


#include <iostream>

int main (){

  double componente_x{0}, componente_y{0};

  std::cin >> componente_x; //Pedimos la componente x
  std::cin >> componente_y; //Pedimos la componente y

  if(componente_x < 1.0 && componente_y < 1.0){ //Comprubea si se sale del cuadrado o está dentro
    std::cout << "dentro" << std::endl;
  } else {
    std::cout << "fuera" << std::endl; 
  }

  return 0; //Termina el programa sin errores
}