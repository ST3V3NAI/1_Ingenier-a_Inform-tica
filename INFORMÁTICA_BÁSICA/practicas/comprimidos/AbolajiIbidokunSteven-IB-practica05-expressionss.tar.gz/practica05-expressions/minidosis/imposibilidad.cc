#include <iostream>

int main () {

  char a{}, b{}, c{};

  c == 'a' && c == 'b';
  a > 1 && a < -1;
  c != 'a' && c == 'a';
  a / b == 1 && b > a;

  return 0;
}




