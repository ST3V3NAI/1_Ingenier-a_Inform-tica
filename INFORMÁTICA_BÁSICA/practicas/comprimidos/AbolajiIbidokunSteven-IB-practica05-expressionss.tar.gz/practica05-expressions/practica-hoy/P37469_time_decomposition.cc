#include <iostream>

int main(){
  int number_of_h{}, number_of_m{}, number_of_s{};

  std::cin >> number_of_s;

  number_of_h = (number_of_s / 3600);
  number_of_m = (number_of_s % 3600) / 60;
  number_of_s = (number_of_s % 3600) % 60;


  std::cout << number_of_h << " " << number_of_m <<  " " << number_of_s << std::endl; 

  return 0;
}
