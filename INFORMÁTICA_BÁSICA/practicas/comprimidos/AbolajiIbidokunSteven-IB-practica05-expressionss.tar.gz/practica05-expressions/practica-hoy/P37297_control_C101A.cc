#include <iostream>

int main(){
  int natural_number{}, suma_de_los_últimos_tres{}; 

  std::cin >> natural_number; 
  
  if(natural_number >= 100){
    for(int i = 0; natural_number <  i++){
      

   }
  }
