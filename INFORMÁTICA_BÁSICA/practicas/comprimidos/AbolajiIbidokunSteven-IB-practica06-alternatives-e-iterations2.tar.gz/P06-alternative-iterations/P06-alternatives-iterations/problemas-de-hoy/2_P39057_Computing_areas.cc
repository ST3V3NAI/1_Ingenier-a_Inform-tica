/**
* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Informática Básica 2023-2024
*
* @file P34279_addsecond.cc
* @author Steven Abolaji Ibidokun  alu0101619613@ull.edu.es
* @date Oct 28 2023
* @brief Write a program that reads several descriptions of rectangles and circles, and for each one prints its corresponding area.
* @bug There are no known bugs
* @see
* https://docs.google.com/document/d/1IVXL8p2OQH20hNdabSTur1dDnDyKI8XYvHtJt1    9KT        jg/edit
*/

#include <iomanip>
#include <iostream>
#include <cmath>

using namespace std;

int main() {
    unsigned int numero_de_figuras{0};
    cin >> numero_de_figuras;
    if(numero_de_figuras == 0) {
        return 0;
    }

  const double pi = atan(1)*4;
    string figura;
    double altura{0}, base{0}, radio{0};

    for (int i = 0; i < numero_de_figuras; i++) {
        cin >> figura;
        if (figura == "rectangle") {
            cin >> altura >> base;
            cout << fixed << setprecision(6)<< altura*base << std::endl;
        }
        else if (figura == "circle") {
            cin >> radio;
            cout << fixed << setprecision(6)<< pi * pow(radio,2) << std::endl;
        }
    }
    return 0;
}
