/**
* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Informática Básica 2023-2024
*
* @file P34279_addsecond.cc
* @author Steven Abolaji Ibidokun  alu0101619613@ull.edu.es
* @date Oct 28 2023
* @brief Write a program that reads sequences of natural numbers, and that for each one prints the number of pairs of consecutive numbers such that the 
second number of the pair is greater than the first one.
* @bug There are no known bugs
* @see
* https://docs.google.com/document/d/1IVXL8p2OQH20hNdabSTur1dDnDyKI8XYvHtJt1    9KT        jg/edit
*/

#include <iostream>
int main() {
  int number{};

  std::cin >> number;
  for (int i = 1; i <= number; ++i) {
    int count = 0;
    int previous{}, next{};
    std::cin >> previous;
      while (previous > 0) {
        std::cin >> next;
        if (previous < next) ++count;
        previous = next;
      }
      
    std::cout << count << std::endl;
  }
  return 0;
}