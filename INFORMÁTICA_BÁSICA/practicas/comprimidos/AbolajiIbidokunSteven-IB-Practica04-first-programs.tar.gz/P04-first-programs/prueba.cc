#include <iostream>

int main(){
	int variable{2};

	// vairable = 6;
	variable = variable - 4;
	variable++;
	std::cout << variable;
}
