/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file integer_division_and_reminder.cc
  * @author Steven Abolaji Ibidokun alu0101619613@ull.edu.es
  * @date Oct 7 2024
  * @brief The program reads two natural numbers a and b, with b > 0, and prints 
  *        the integer division d and the remainder r of a divided by b.
  *        By definition, d and r must be the only integer numbers such that 0=<r<b and db+r=a.
  * @bug There are no known bugs
  * @see https://jutge.org/problems/P48107
  */


#include <iostream>

int main(){

  int variable_a, variable_b;
  int division{0};
  int remainder{0};

  std::cin >> variable_a >> variable_b;
  
  if(variable_b > 0){
    division = variable_a / variable_b;
    remainder = variable_a % variable_b;
    std::cout << division << " " << remainder << std::endl;
  
  }


  return 0; 
}
