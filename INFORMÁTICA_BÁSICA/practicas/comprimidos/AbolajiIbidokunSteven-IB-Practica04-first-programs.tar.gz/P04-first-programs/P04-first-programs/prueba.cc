#include <iostream>

int main() {
  int operand1{17};
  int operand2{3};
  std::cout << operand1 % operand2;
  return 0;
}
