/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file P11725_Sequential_search_in_a_array.cc
  * @author alu0101619613@ull.edu.es
  * @date Nov 18 2024
  * @brief Write a function that tells if the integer number x is present in the vector of integer numbers v.
  * @bug There are no known bugs
  * @see 
  * 
  */


#include <vector>

/**
 * Checks if an integer x is present in the vector v.
 *
 * @param x The integer to search for.
 * @param v The vector of integer numbers.
 * @return true if x is found in v, false otherwise.
 */
bool exists(int x, const std::vector<int>& v) {
    for (int number : v) {
        if (number == x) {
            return true;
        }
    }
    return false;
}
