/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file 2_P26492_Balanced.cc
  * @author Steven Abolaji Ibidokun alu0101619613@ull.edu.es
  * @date Nov 18 2024
  * @brief Write a function that swaps two numbers.
  * @bug There are no known bugs
  * @see 
  */

/**
 * 
 * @brief This function checks if a number of digits, the even 
 * pos are equal to the odds pos, if that is not posible, it will return false
 * @param n The integer number
 * @return true or false otherwise.
 */
bool is_balanced(int n){
    int pos{1}, sum_even_pos{0}, sum_odd_pos{0};

    while(n > 0) {
        int digit = n % 10;

        if (pos % 2 == 0){
          sum_even_pos += digit;
        } else {
          sum_odd_pos += digit;
        }

        n /= 10;
        pos++;
    }

    // If the sum of the even position are the same as the odd position will print true
    if(sum_even_pos == sum_odd_pos){
       return true;
    } else {
       return false;
    }
}
