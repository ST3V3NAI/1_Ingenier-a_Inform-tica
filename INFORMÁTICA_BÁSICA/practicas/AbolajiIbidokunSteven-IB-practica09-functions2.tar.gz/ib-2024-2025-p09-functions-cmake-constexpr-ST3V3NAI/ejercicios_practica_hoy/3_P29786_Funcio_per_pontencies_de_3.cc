/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file 3_P61930_Multiples_of_three.cc
  * @author Steven Abolaji Ibidokun alu0101619613@ull.edu.es
  * @date Nov 18 2024
  * @brief Write a function that swaps two numbers.
  * @bug There are no known bugs
  * @see 
  */


#include <iostream>
/**
 * @brief This function use the other function created to check if the sum of the digits are a power of 3
 * @param n The integer number
 * @return true if is a power of 3, and false otherwise
 */

bool es_potencia_de_3(int n){
   if(n <= 0) return false;
   while(n % 3 == 0){
      n /= 3;
   }
    return n == 1;
   }


