/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file aproximate_root_main.cc
  * @author Steven
  * @date Nov 11 2024
  * @brief Implementación de funciones para conseguir el error
  * @bug There are no known bugs
  */

#include "aproximate_root.h"
#include <string>
#include <iostream>

int main (int argc, char *argv[]) {
  PrintProgramPurpose();

  if(!CheckCorrectParameters(argc, argv, 3)){
    return 1;
  }

  double number = std::atoi(argv[1]);
  float error = std::atoi(argv[2]);

  float result = AproximateRoot(number, error);

  std::cout << result << std::endl;


}