/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file aproximate_root.cc
  * @author Steven
  * @date Nov 11 2024
  * @brief Programa que te hace una raiz aproximada del valor que le des
  * @bug There are no known bugs
  */

#include "aproximate_root.h"
#include <string>
#include <iostream>

void PrintProgramPurpose() {
   std::cout << "This program that takes number over 0 and gives you it square root with an error of +- EPSILON" << std::endl << std::endl;
}

bool CheckCorrectParameters(const int argc, char *argv[], const int kCorrectNumber = 3) {
  if (argc != kCorrectNumber) {
    std::cout << "This program has been executed with a wrong number of parameters." << std::endl;
    std::cout << "This program should be called as: " << argv[0] << " <number> <error>" << std::endl;
    return false;
  }
  return true;
}

double AproximateRoot(double number, const double& kEpsilon){
  double root{1.0}, delta{1.0};

while (std::fabs(pow(root,2) - number) > kEpsilon) {
        if (delta > 0) {
            while ((pow(root,2)) < number) {
                root += delta;
            }
        } else {
            while ((pow(root,2)) > number) {
                root += delta;
            }
        }
        delta *= -0.5;
    }
    return root;
}