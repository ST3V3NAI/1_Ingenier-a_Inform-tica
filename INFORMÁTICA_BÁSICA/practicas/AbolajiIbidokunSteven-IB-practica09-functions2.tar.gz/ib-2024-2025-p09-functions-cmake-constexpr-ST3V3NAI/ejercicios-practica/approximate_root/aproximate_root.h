/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file aproximate_root.h
  * @author Steven
  * @date Nov 11 2024
  * @brief Definicion Funciones del programa
  * @bug There are no known bugs
  */


#ifndef APROXIMATE_ROOT_H
#define APROXIMATE_ROOT_H

#include <iostream>
#include <cmath>

void PrintProgramPurpose();
bool CheckCorrectParameters(int argc, char *argv[], const int kCorrectNumber);
double AproximateRoot(double number, const double& kEpsilon);

#endif