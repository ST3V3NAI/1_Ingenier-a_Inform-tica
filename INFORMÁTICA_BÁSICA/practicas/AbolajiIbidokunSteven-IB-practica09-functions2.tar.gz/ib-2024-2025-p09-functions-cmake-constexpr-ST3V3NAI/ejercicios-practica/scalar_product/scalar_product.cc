/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file scalar_product.cc
  * @author Steven
  * @date Nov 11 2024
  * @brief Programa que al darle dos vectores, te da su suma escalar
  * @bug There are no known bugs
  */

#include "scalar_product.h"

void PrintProgramPurpose() {
   std::cout << "This program that operates two vectors given and displays tehir scalar product" << std::endl << std::endl;
}

bool CheckCorrectParameters(const int argc, char *argv[], const int kCorrectNumber = 7) {
  if (argc != kCorrectNumber) {
    std::cout << "This program has been executed with a wrong number of parameters." << std::endl;
    std::cout << "This program should be called as: " << argv[0] << " <x1> <x2> <x3> <y1> <y2> <y3>" << std::endl;
    return false;
  }
  return true;
}

double ScalarProduct(const std::vector<double>& vector_1, const std::vector<double>& vector_2){
    double product{};
    for (int i = 0; i < vector_1.size(); i++) {
        product += (vector_1[i] * vector_2[i]);
    }

    return product;

}