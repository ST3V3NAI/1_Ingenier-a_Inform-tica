/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file scalar_product.h
  * @author Steven
  * @date Nov 11 2024
  * @brief Definicion Funciones del programa
  * @bug There are no known bugs
  */


#ifndef SCALAR_PRODUCT_H
#define SCALAR_PRODUCT_H

#include <iostream>
#include <vector>

void PrintProgramPurpose();
bool CheckCorrectParameters(int argc, char *argv[], const int kCorrectNumber);
double ScalarProduct(const std::vector<double>& vector_1, const std::vector<double>& vector_2);
#endif