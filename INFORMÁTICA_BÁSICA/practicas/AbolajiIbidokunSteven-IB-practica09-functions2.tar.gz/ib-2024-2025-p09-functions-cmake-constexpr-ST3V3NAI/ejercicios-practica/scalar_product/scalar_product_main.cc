/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file scalar_product_main.cc
  * @author Steven
  * @date Nov 11 2024
  * @brief Implementación de funciones para conseguir el producto escalar
  * @bug There are no known bugs
  */

#include "scalar_product.h"
#include <iostream>
#include <sstream>
#include <string>

int main (int argc, char *argv[]) {
  PrintProgramPurpose();

  if(!CheckCorrectParameters(argc, argv, 7)){
    return 1;
  }

  double x1 = std::atoi(argv[1]);
  double x2 = std::atoi(argv[2]);
  double x3 = std::atoi(argv[3]);
  double y1 = std::atoi(argv[4]);
  double y2 = std::atoi(argv[5]);
  double y3 = std::atoi(argv[6]);

  std::vector <double> vector_1 {x1,x2,x3};
  std::vector <double> vector_2 {y1,y2,y3};

  std::cout << "El producto escalar es: " << ScalarProduct(vector_1, vector_2);

}