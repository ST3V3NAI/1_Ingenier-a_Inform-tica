/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file hypotenuse.cc
  * @author Steven
  * @date Nov 11 2024
  * @brief Programa que al darle dos cateto te imprime la hipotenusa
  * @bug There are no known bugs
  */

#include "hypotenuse.h"
#include <string>
#include <iostream>


void PrintProgramPurpose() {
   std::cout << "This program calculates the hypotenuse of a given to sides of a triangle" << std::endl << std::endl;
}

bool CheckCorrectParameters(const int argc, char *argv[], const int kCorrectNumber = 3) {
  if (argc != kCorrectNumber) {
    std::cout << "This program has been executed with a wrong number of parameters." << std::endl;
    std::cout << "This program should be called as: " << argv[0] << " <cathetus 1> <cathetus 2>" << std::endl;
    return false;
  }
  return true;
}


double Hypotenuse(double cathethus1, double cathethus2){
  double hypotenuse = sqrt(pow(cathethus1,2) + pow(cathethus2,2));
  return hypotenuse;
}
