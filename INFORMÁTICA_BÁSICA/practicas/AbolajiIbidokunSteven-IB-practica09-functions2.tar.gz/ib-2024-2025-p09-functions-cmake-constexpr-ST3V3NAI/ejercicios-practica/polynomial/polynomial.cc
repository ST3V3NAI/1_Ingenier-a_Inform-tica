/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file polynomial.cc
  * @author Steven
  * @date Nov 11 2024
  * @brief Programa que al darle una serie de numeros de calcula el polynomio, dado un valor x
  * @bug There are no known bugs
  */

#include "polynomial.h"

void PrintProgramPurpose() {
   std::cout << "This program due a coefficients and a value calculates a function" << std::endl << std::endl;
}

bool CheckCorrectParameters(const int argc, char *argv[], const int kCorrectNumber = 7) {
  if (argc != kCorrectNumber) {
    std::cout << "This program has been executed with a wrong number of parameters." << std::endl;
    std::cout << "This program should be called as: " << argv[0] << " <x1> <x2> <x3> <x4> <x5> <value>" << std::endl;
    return false;
  }
  return true;
}

double PolynomialEvaluation(const std::vector<int>& vector_1, const double& value_x) {
    double result{};
    for (size_t i = vector_1.size(); i > 0; --i) {
        result = result * value_x + vector_1[i - 1];
    }
    return result;
}