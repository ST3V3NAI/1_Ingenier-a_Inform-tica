/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file polynomial_main.cc
  * @author Steven
  * @date Nov 11 2024
  * @brief Implementación de funciones para conseguir el resultado del polinomio
  * @bug There are no known bugs
  */

#include "polynomial.h"
#include <iostream>
#include <sstream>
#include <string>

int main (int argc, char *argv[]) {
  PrintProgramPurpose();

  if(!CheckCorrectParameters(argc, argv, 7)){
    return 1;
  }

  int x1 = std::atoi(argv[1]);
  int x2 = std::atoi(argv[2]);
  int x3 = std::atoi(argv[3]);
  int x4 = std::atoi(argv[4]);
  int x5 = std::atoi(argv[5]);

  int value_x = std::atoi(argv[6]);

  std::vector <int> vector_1{x1,x2,x3,x4,x5};

  std::cout << PolynomialEvaluation(vector_1, value_x);

}