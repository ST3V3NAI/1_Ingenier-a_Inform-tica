/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file polynomial.h
  * @author Steven
  * @date Nov 11 2024
  * @brief Definicion Funciones del programa
  * @bug There are no known bugs
  */


#ifndef POLYNOMIAL_H
#define POLYNOMIAL_H

#include <iostream>
#include <vector>

void PrintProgramPurpose();
bool CheckCorrectParameters(int argc, char *argv[], const int kCorrectNumber);
double PolynomialEvaluation(const std::vector<int>& vector_1, const double& value_x);
#endif