/**
  * Universisdad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica
  * 
  * @file 3_P12061_Words_between_two_words.cc
  * @author Abolaji Ibidokun Steven alu0101619613@ull.edu.es
  * @date 25 Nov 2024
  * @brief Write a program that, given a sequence of words, prints the number of words between the word “beginning” and the word “end”. If the word “beginning”, the word “end” or both words are missing, or if they appear in inverse order, tell so.
  * @bug There are no known bugs
  * @see https://jutge.org/problems/P14130_en
  */ 
 
#include <iostream>
#include <string>

int main() {
  std::string sequence;
  bool appear = false;
  int counter{0};
  
  while (std::cin >>  sequence) {
    if (sequence == "end") {
      if (appear) std::cout << counter << std::endl;
      else std::cout << "wrong sequence" << std::endl;
      return 1;
    }
    if (appear) counter++;
    if (sequence == "beginning") appear = true;
  }
  std::cout << "wrong sequence" << std::endl;
}

