/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file P29094_Position_of_the_maximum.cc
  * @author Steven
  * @date Nov 25 2024
  * @brief Write a function that returns the position of the maximum element of v[0..m]. If there is a tie, the smaller position must be returned.
  * @bug There are no known bugs
  */

#include <vector>
#include <limits> 

int position_maximum(const std::vector<double>& v, int m) {
    double max_val = std::numeric_limits<double>::lowest();
    int max_pos = -1;

    for (int i = 0; i <= m; ++i) {
        if (v[i] > max_val) {
            max_val = v[i];
            max_pos = i;
        }
    }

    return max_pos;
}
