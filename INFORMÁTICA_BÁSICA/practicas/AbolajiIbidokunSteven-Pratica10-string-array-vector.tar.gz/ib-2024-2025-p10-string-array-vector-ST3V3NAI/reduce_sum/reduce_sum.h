/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file reduce_sum.h
  * @author Steven
  * @date Nov 19 2024
  * @brief Definicion Funciones del programa
  * @bug There are no known bugs
  */


#ifndef REDUCE_SUM_H
#define REDUCE_SUM_H

#include <string>
#include <cmath>
#include <vector>

void PrintProgramPurpose();
bool CheckCorrectParameters(int argc, char *argv[], const int kCorrectNumber);
double ReduceSum(const std::vector<double>& numeros);
#endif