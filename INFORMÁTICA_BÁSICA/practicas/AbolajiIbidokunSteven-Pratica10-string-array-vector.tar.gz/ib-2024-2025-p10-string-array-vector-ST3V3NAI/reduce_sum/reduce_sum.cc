/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file generate_vector.cc
  * @author Steven
  * @date Nov 19 2024
  * @brief Programa que genera y devueleve un vector de size componentes una vez dado el upper y el lower.
  * @bug There are no known bugs
  */

#include "generate_vector.h"
#include <string>
#include <iostream>


void PrintProgramPurpose() {
   std::cout << "This program sum all the values of a vector" << std::endl << std::endl;
}

bool CheckCorrectParameters(const int argc, char *argv[], const int kCorrectNumber = 3) {
  if (argc != kCorrectNumber) {
    std::cout << "This program has been executed with a wrong number of parameters." << std::endl;
    std::cout << "This program should be called as: " << argv[0] << " <cathetus 1> <cathetus 2>" << std::endl;
    return false;
  }
  return true;
}


double ReduceSum(const std::vector<double>& numeros){
  double suma{0.0};
  for(double num : numeros) {
    suma += num;
  }
  return suma;
}