/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file generate_vector.cc
  * @author Steven
  * @date Nov 19 2024
  * @brief Programa que genera y devueleve un vector de size componentes una vez dado el upper y el lower.
  * @bug There are no known bugs
  */

#include "disordered_vector.h"
#include <string>
#include <iostream>

void desordenarVector(std::vector<int>& vec) {
    // Inicializa la semilla del generador de números aleatorios
    std::srand(static_cast<unsigned int>(std::time(0)));

    // Recorrer el vector e intercambiar cada elemento con otro en una posición aleatoria
    for (size_t i = 0; i < vec.size(); ++i) {
        size_t posAleatoria = i + std::rand() % (vec.size() - i); // Generar una posición entre i y el final
        std::swap(vec[i], vec[posAleatoria]);
    }
}

