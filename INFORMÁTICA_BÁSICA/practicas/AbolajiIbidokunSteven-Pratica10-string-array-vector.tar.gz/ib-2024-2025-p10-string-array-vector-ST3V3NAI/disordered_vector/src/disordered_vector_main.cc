/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file hypotenuse_main.cc
  * @author Steven
  * @date Nov 11 2024
  * @brief Implementación de funciones pa conseguir la hipotenusa
  * @bug There are no known bugs
  */

#include <string>
#include <iostream>

#include "disordered_vector.h"
#include "tools.h"


int main (int argc, char *argv[]) {
  Usage(argc, argv);
  
  std::vector<int> miVector = {1, 2, 3, 4, 5, 6, 7, 8, 9};
    std::cout << "Vector original: ";
    for (int num : miVector) {
        std::cout << num << " ";
    }
    std::cout << std::endl;
    // Desordenar el vector
    desordenarVector(miVector);
    std::cout << "Vector desordenado: ";
    for (int num : miVector) {
        std::cout << num << " ";
    }
    std::cout << std::endl;
    return 0;
}