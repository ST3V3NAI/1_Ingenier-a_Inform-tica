/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file generate_vector.h
  * @author Steven
  * @date Nov 19 2024
  * @brief Definicion Funciones del programa
  * @bug There are no known bugs
  */


#ifndef DISORDERED_VECTOR_H
#define DISORDERER_VECTOR_H

#include <iostream>
#include <vector>
#include <cstdlib> // Para std::rand y std::srand
#include <ctime>   // Para std::time

void desordenarVector(std::vector<int>& vec);
#endif