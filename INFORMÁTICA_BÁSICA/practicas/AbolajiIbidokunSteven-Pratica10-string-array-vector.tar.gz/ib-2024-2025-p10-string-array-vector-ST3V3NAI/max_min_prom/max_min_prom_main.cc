/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file hypotenuse_main.cc
  * @author Steven
  * @date Nov 11 2024
  * @brief Implementación de funciones pa conseguir la hipotenusa
  * @bug There are no known bugs
  */

#include "max_min_prom.h"
#include <string>
#include <iostream>

int main (int argc, char *argv[]) {
  PrintProgramPurpose();

  if(!CheckCorrectParameters(argc, argv, 3)){
    return 1;
  }

   std::vector<double> my_vector = GenerateVector(30, 5.0, 10.0);

    // Variables para almacenar el máximo, mínimo y promedio
    double max, min, avg;

    // Calculamos las estadísticas
    CalculateStats(my_vector, max, min, avg);

    // Mostramos los resultados
    std::cout << "Valores del vector:\n";
    for (const auto& value : my_vector) {
        std::cout << value << " ";
    }
    std::cout << "\n\nEstadísticas:\n";
    std::cout << "Máximo: " << max << "\n";
    std::cout << "Mínimo: " << min << "\n";
    std::cout << "Promedio: " << avg << "\n";

    return 0;
}