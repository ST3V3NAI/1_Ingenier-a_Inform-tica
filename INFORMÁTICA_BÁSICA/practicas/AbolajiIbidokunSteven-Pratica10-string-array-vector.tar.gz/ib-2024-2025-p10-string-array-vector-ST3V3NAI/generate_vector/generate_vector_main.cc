/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file hypotenuse_main.cc
  * @author Steven
  * @date Nov 11 2024
  * @brief Implementación de funciones pa conseguir la hipotenusa
  * @bug There are no known bugs
  */

#include "generate_vector.h"
#include <string>
#include <iostream>

int main (int argc, char *argv[]) {
  PrintProgramPurpose();

  if(!CheckCorrectParameters(argc, argv, 3)){
    return 1;
  }

std::vector<double> my_vector = GenerateVector(30, 5.0, 10.0);
  for (const auto& value: my_vector) {
    std::cout << "Component: " << value << std::endl;
  }

}