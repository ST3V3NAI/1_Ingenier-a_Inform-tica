/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @file generate_vector.h
  * @author Steven
  * @date Nov 19 2024
  * @brief Definicion Funciones del programa
  * @bug There are no known bugs
  */


#ifndef GENERATE_VECTOR__H
#define GENERATE_VECTOR_H

#include <string>
#include <cmath>
#include <vector>

void PrintProgramPurpose();
bool CheckCorrectParameters(int argc, char *argv[], const int kCorrectNumber);
std::vector<double> GenerateVector(const int size, const double lower, const double upper);
#endif